
public class PrimeNumbers {
	

	
	public static void main(String[] args) {
		
		int[] primes = decomposeIntIntoPrimes(78);
		showResult(primes);
	}

	public static int[] decomposeIntIntoPrimes(int num) {
		
		int[] primes = new int[6];
		int pointer = 0;
		
		if (num == 1) {
			primes[0] = 1;
			return primes;
		}
		
		for (int i = 2; i <= num; i++) {
			if (num % i == 0) {
				num = num / i;
				primes[pointer] = i;
				pointer++;
				i = 1;
			}
			
		}
		return primes;
	}
	
	public static void showResult(int[] primes) {
		
		for (int i = 0; i < primes.length && primes[i] != 0; i++) {
			System.out.print(primes[i] + ", ");
		}
		
	}
	
}
